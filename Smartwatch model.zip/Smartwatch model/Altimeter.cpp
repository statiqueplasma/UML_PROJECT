/**
 * Project Smartwatch
 */


#include "Altimeter.h"

/**
 * Altimeter implementation
 */


/**
 * @return float
 */
float Altimeter::get_alt() {
    return 0.0;
}