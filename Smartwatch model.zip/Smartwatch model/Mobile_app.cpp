/**
 * Project Smartwatch
 */


#include "Mobile_app.h"

/**
 * Mobile_app implementation
 */


void Mobile_app::Pair() {

}

void Mobile_app::Send_time() {

}

/**
 * @return int
 */
int Mobile_app::Request_HR() {
    return 0;
}

/**
 * @return float
 */
float Mobile_app::Request_bat_lvl() {
    return 0.0;
}

/**
 * @return int
 */
int Mobile_app::Request_GPS() {
    return 0;
}

/**
 * @return float
 */
float Mobile_app::Request_Alt() {
    return 0.0;
}