/**
 * Project Smartwatch
 */


#include "GPS_Sensor.h"

/**
 * GPS_Sensor implementation
 */


/**
 * @return GPS_coord
 */
GPS_coord GPS_Sensor::get_gps() {
    return null;
}