/**
 * Project Smartwatch
 */


#include "Sensor.h"

/**
 * Sensor implementation
 */


void Sensor::Start_measure() {

}

void Sensor::Stop_measure() {

}