/**
 * Project Smartwatch
 */


#ifndef _SENSOR_H
#define _SENSOR_H

class Sensor {
private: 
    bool measureInProgress;
    
void Start_measure();
    
void Stop_measure();
};

#endif //_SENSOR_H