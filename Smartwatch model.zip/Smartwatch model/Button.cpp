/**
 * Project Smartwatch
 */


#include "Button.h"

/**
 * Button implementation
 */


/**
 * @return bool
 */
bool Button::get_status() {
    return false;
}