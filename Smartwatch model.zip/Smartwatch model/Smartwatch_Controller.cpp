/**
 * Project Smartwatch
 */


#include "Smartwatch_Controller.h"

/**
 * Smartwatch_Controller implementation
 */


void Smartwatch_Controller::Toggle_Power() {

}

/**
 * @return int
 */
int Smartwatch_Controller::Mesure_HR() {
    return 0;
}

/**
 * @return float
 */
float Smartwatch_Controller::Mesure_Alt() {
    return 0.0;
}

/**
 * @return GPS_coord
 */
GPS_coord Smartwatch_Controller::Mesure_GPS() {
    return null;
}

/**
 * @return GPS_coord
 */
GPS_coord Smartwatch_Controller::get_GPS_Pos() {
    return null;
}

/**
 * @return float
 */
float Smartwatch_Controller::get_bat_lvl() {
    return 0.0;
}

/**
 * @return int
 */
int Smartwatch_Controller::get_HR() {
    return 0;
}

/**
 * @return float
 */
float Smartwatch_Controller::get_Alt() {
    return 0.0;
}

/**
 * @return Time
 */
Time Smartwatch_Controller::get_time() {
    return null;
}

/**
 * @return Time
 */
Time Smartwatch_Controller::Request_Time() {
    return null;
}

void Smartwatch_Controller::Send_GPS() {

}

void Smartwatch_Controller::Send_HR() {

}

void Smartwatch_Controller::Send_Alt() {

}

void Smartwatch_Controller::Send_bat_lvl() {

}