/**
 * Project Smartwatch
 */


#include "Battery.h"

/**
 * Battery implementation
 */


/**
 * @return float
 */
float Battery::get_bat_lvl() {
    return 0.0;
}