/**
 * Project Smartwatch
 */


#ifndef _MOTION_TYPE_H
#define _MOTION_TYPE_H

enum Motion_type {IDLE, PRESS, SLIDE_LEFT, SLIDE_RIGHT };

#endif //_MOTION_TYPE_H