/**
 * Project Smartwatch
 */


#include "User.h"

/**
 * User implementation
 */


void User::Login() {

}

void User::Logout() {

}

void User::Pair() {

}

void User::Mesure_HR() {

}

void User::Mesure_Alt() {

}

void User::App_Cmd() {

}