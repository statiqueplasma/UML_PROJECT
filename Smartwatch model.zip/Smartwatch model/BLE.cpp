/**
 * Project Smartwatch
 */


#include "BLE.h"

/**
 * BLE implementation
 */


void BLE::Send_Trame() {

}

void BLE::Receive_Trame() {

}