/**
 * Project Smartwatch
 */


#include "Heart_Rate_sensor.h"

/**
 * Heart_Rate_sensor implementation
 */


/**
 * @return int
 */
int Heart_Rate_sensor::get_hr() {
    return 0;
}